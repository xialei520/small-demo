'use strict';

const spinners = Object.assign({}, require('./spinners.json'));

module.exports = spinners;
// TODO: Remove this for the next major release
module.exports.default = spinners;
